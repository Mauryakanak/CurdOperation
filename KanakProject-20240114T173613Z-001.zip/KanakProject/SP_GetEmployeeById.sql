CREATE PROCEDURE GetEmployeeById
    @EmployeeId int
AS
BEGIN
    SELECT
        EmployeeId,
        Name,
        Gender,
        Mobile,
        Email,
        Password,
        DateOfBirth,
        Status
    FROM
        Employee
    WHERE
        EmployeeId = @EmployeeId;
END;
