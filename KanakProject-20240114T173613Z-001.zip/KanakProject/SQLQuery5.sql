USE [Project]
GO

/****** Object:  StoredProcedure [dbo].[GetEmployeeDetails]    Script Date: 1/14/2024 7:17:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

alter PROCEDURE [dbo].[GetEmployeeDetails]
AS
BEGIN
    SELECT
        E.EmployeeId,
        E.Name,
        E.Gender,
        E.Mobile,
        E.Email,
        E.Password,
        E.DateOfBirth,
        E.Status,
        ED.EmpExperienceId,
        ED.CompanyName,
        ED.StartDate,
        ED.EndDate,
        ED.CTC,
        ED.IsCurrentlyWorking,
        ED.ReasonForLeaving,
        ED.Status AS ExperienceStatus
    FROM
        Employee E
    LEFT JOIN
        EmployeeExperienceDetails ED ON E.EmployeeId = ED.EmployeeId
    where e.Status=1;
END;
GO


